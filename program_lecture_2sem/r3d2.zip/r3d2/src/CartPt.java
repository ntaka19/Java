
public class CartPt {
	int x;
	int y;
	
	CartPt(int x, int y){
		this.x = x;
		this.y = y;
		
	}
}
