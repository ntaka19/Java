package r6d2a;

public class Author {
	String name;
	int birthyear;
	
	Author(String name,int birthyear){
		this.name = name;
		this.birthyear = birthyear;
	}
}
