package r6d2c;

public interface IPatient {
	public Patient getPatient(int n);
	public int length();
}
