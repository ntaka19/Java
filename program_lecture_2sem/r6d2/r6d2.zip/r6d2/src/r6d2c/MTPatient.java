package r6d2c;

public class MTPatient implements IPatient{
	public Patient getPatient(int n){
		throw new RuntimeException("the given numbers do not specify a patient");
	}
	public int length(){
		return 0;
	}

}
